# Q1
def frequency(text):
    dic = {}
    for word in text.lower().split():
        if word not in dic:
            dic[word] = 1
        else:
            dic[word] += 1
    return dic

# Q2
def Char_freq(word):
    dic = {}
    for char in word.lower():
        if char not in dic:
            dic[char] = 1
        else:
            dic[char] += 1
    return dic

# Q3
def non_rep_char(word):
    dic = {}
    for i in word.lower():
        if i not in dic:
            dic[i] = 1
        else:
            dic[i] += 1
    for j,k in dic.items():
        if k == 1:
            return j
    return None

# Q4
def anagram(text1,text2):
    if len(text1) == len(text2) and sorted(text1.lower()) == sorted(text2.lower()):
        return True
    else:
        return False

# Q5
def first_rep_char(text):
    d = {}
    for i in text.lower():
        if i in d:
            return i
        else:
            d[i] = 1
    return None

# Q6
def zeros_end(num):
    result = [i for i in num if i != 0] + [i for i in num if i == 0]
    return result

# Q7
def sec_lar_dis(num):
    lar = None
    sec_lar = None
    for i in num:
        if  lar is None or i > lar:
            sec_lar = lar
            lar = i
        elif (sec_lar is None or i > sec_lar) and i!= lar:
            sec_lar = i
    return  sec_lar

# Q8
def remove_dups(nums):
    l = []
    for i in nums:
        if nums.count(i) > 1 and i not in l:
            l.append(i)
    return l

# Q9
def missing_num(nums):
    for i in range(1,len(nums)+1):
        if i not in nums:
            return i
    return None

# Q10
def sum_target(nums,target):
    pairs = []
    for i in range(len(nums)):
        for j in range(i+1,len(nums)):
            if nums[i] + nums[j] == target:
                pairs.append(nums[i])
                pairs.append(nums[j])
    return pairs

# Q11
def closest_zero(nums):
    closest = nums[0]
    for i in nums:
        if abs(i) < abs(closest):
            closest = i
        elif abs(i) == abs(closest) and i > closest:
            closest = i
    return closest

# Q12
def common_elements(li1,li2):
    common = []
    for i in li1:
        if i in li2:
            common.append(i)
    return common

# Q13
def rotate_right(li,k):
    k = k % len(li)
    li = li[-k:] + li[:-k]
    return li

# Q14
def maxi_sum(li):
    lar = li[0] + li[1]
    for i in range(1,len(li) - 1):
        current = li[i] + li[i+1]
        if current > lar:
            lar = current
    return lar

# Q15
def pairs_sum(li,target):
    lis = []
    for i in range(len(li)):
        for j in range(i+1,len(li)):
            if (li[i] + li[j]) == target:
                lis.append([li[i],li[j]])

    return lis