# Q1
from Solutions import frequency
text = "python is easy and python is powerful"
print(frequency(text))

text2 = "Javascript is used for Backend"
print(frequency(text2))

# Q2
from Solutions import Char_freq
word = "banana"
print(Char_freq(word))

w1 = "Areoplane"
print(Char_freq(w1))

# Q3
from Solutions import non_rep_char
word = "swiss"
print(non_rep_char(word))

word1 = "Aaccess"
print(non_rep_char(word1))

# Q4
from Solutions import anagram
t1 = "listen"
t2 = "slient"
print(anagram(t1,t2))

t3 = "yummy"
t4 = "tummy"
print(anagram(t3,t4))

# Q5
from Solutions import first_rep_char
text = "programming"
print(first_rep_char(text))

text1 = "Abstraction"
print(first_rep_char(text1))

# Q6
from Solutions import zeros_end
num = [0,3,0,1,2,0,4]
print(zeros_end(num))

num1 = [5,0,7,0,3,0,2,0,1,0,4,0,6]
print(zeros_end(num1))

# Q7
from Solutions import sec_lar_dis
num = [10, 20, 40, 30, 40, 20]
print(sec_lar_dis(num))

num1 = [15,5,35,25,45,15,5,35,25,45]
print(sec_lar_dis(num1))

# Q8
from Solutions import remove_dups
num1 = [4, 2, 4, 5, 2, 7, 5]
print(remove_dups(num1))

num2 = [3,4,2,3,5,6,1,2,3,5]
print(remove_dups(num2))

# Q9
from Solutions import missing_num
num1 =  [1, 2, 4, 5, 6]
print(missing_num(num1))

num2 = [1, 2,3, 4, 5, 6, 8, 9, 10]
print(missing_num(num2))

# Q10
from Solutions import sum_target
n = [2,7,11,15]
print(sum_target(n,9))

num2 = [1,2,3,4,5]
print(sum_target(num2,7))

# Q11
from Solutions import closest_zero
int_list = [-8,-3,2,-5,-2]
print(closest_zero(int_list))

int2 = [-5,-4,-3,-2,-1,2,3,4,5]
print(closest_zero(int2))

# Q12
from Solutions import common_elements
li = [1,2,3,4,5]
li2 = [3,4,5,6,7]
print(common_elements(li,li2))

li3 = [10,20,30,40,50]
li4 = [50,60,70,20,30]
print(common_elements(li3,li4))

# Q13
from Solutions import rotate_right
nums = [1, 2, 3, 4, 5]
print(rotate_right(nums,2))

num2 = [1,2,3,4,5,6]
print(rotate_right(num2,4))

# Q14
from Solutions import maxi_sum
nums = [4,7,2,9,5]
print(maxi_sum(nums))

num1 = [2,4,1,8,2,9]
print(maxi_sum(num1))

# Q15
from Solutions import pairs_sum
nums = [2, 4, 3, 5, 7, 8, 1]
print(pairs_sum(nums,9))

num1 = [5,2,3,1,4,6,7,8]
print(pairs_sum(num1,6))